$(function() {
    if (window?.XMLHttpRequest) {
        let postsHTML = $(".body_posts");
        let notify = $(".notify");
        let timerId = 0;

        postsHTML.on( "click", ".published", function() {
            let getHTML = $(this).closest('.id_post');
            let id = getHTML.data('id');

            $.ajax({
                url: '/api/post/published.php',
                method: 'POST',
                data: {
                    id
                },
                success: function (d) {
                    clearTimeout(timerId);
                    let btnChange = getHTML.find(".publishedTd");
                    btnChange.html("<button type='button' class='btn btn-warning rejected'>Отклонить</button>");
                    btnChange.toggleClass("publishedTd rejectedTd");
                    notify.html(`<div class="alert alert-success">${d?.result?.msg}</div>`);
                    timerId = setTimeout(function () {
                        notify.html(``);
                    }, 3000)
                },
                error: function (d) {
                    clearTimeout(timerId);
                    notify.html(`<div class="alert alert-danger">${d?.responseJSON?.result?.msg}</div>`);
                    timerId = setTimeout(function () {
                        notify.html(``);
                    }, 3000)
                }
            })
        });
        postsHTML.on( "click", ".rejected", function() {
            let getHTML = $(this).closest('.id_post');
            let id = getHTML.data('id');

            $.ajax({
                url: '/api/post/rejected.php',
                method: 'POST',
                data: {
                    id
                },
                success: function (d) {
                    clearTimeout(timerId);
                    let btnChange = getHTML.find(".rejectedTd");
                    btnChange.html("<button type='button' class='btn btn-success published'>Опубликовать</button>");
                    btnChange.toggleClass("rejectedTd publishedTd");
                    notify.html(`<div class="alert alert-success">${d?.result?.msg}</div>`);
                    timerId = setTimeout(function () {
                        notify.html(``);
                    }, 3000)
                },
                error: function (d) {
                    clearTimeout(timerId);
                    notify.html(`<div class="alert alert-danger">${d?.responseJSON?.result?.msg}</div>`);
                    timerId = setTimeout(function () {
                        notify.html(``);
                    }, 3000)
                }
            })
        });
        postsHTML.on( "click", ".deleted", function() {
            let getHTML = $(this).closest('.id_post');
            let id = getHTML.data('id');

            $.ajax({
                url: '/api/post/delete.php',
                method: 'POST',
                data: {
                    id
                },
                success: function (d) {
                    clearTimeout(timerId);
                    getHTML.remove();
                    notify.html(`<div class="alert alert-success">${d?.result?.msg}</div>`);
                    timerId = setTimeout(function () {
                        notify.html(``);
                    }, 3000)
                },
                error: function (d) {
                    clearTimeout(timerId);
                    notify.html(`<div class="alert alert-danger">${d?.responseJSON?.result?.msg}</div>`);
                    timerId = setTimeout(function () {
                        notify.html(``);
                    }, 3000)
                }
            })
        });
    } else {
        alert('Ваша версия браузера устарела, к сожалению поддержки пока нет');
    }
});
